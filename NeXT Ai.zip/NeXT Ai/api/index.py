from NeXT_AI.backend.main import app
# Serveur 