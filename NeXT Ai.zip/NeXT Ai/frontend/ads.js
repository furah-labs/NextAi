document.addEventListener("DOMContentLoaded", () => {
  loadAdvertisements();
});

function loadAdvertisements() {
  const topAdSlot = document.getElementById("ad-banner-top");
  const bottomAdSlot = document.getElementById("ad-banner-bottom");

  if (topAdSlot) {
    topAdSlot.innerHTML = `
      <div style="color: #64748b; font-size: 0.85rem;">
        📢 [ ESPACE PUBLICITAIRE - Chargé dynamiquement par JavaScript ]
      </div>
    `;
  }

  if (bottomAdSlot) {
    bottomAdSlot.innerHTML = `
      <div style="color: #64748b; font-size: 0.85rem;">
        🎯 [ BANNIÈRE SPONSORISÉE - Furah Labs Ad Network ]
      </div>
    `;
   }
